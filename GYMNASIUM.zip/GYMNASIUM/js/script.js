// banner-part start

$('.banner_slider').slick({
  dots: true,
  arrows: true,
  infinite: true,
  speed: 300,
  slidesToShow: 1,
  slidesToScroll: 1,
prevArrow: '<i class="fa fa-angle-left left_arrow" aria-hidden="true"></i>',
nextArrow: '<i class="fa fa-angle-right right_arrow" aria-hidden="true"></i>',
});

//   banner-part end



// testimonial-part start

$('.testislider').slick({
  autoplay:true,
  arrows:false,
  dots: true,
  infinite: true,
  speed: 300,
  slidesToShow: 2,
  slidesToScroll: 1,
});

// testimonial-part end



// counter-part start

$('.counter').counterUp();

// counter-part end




// plugin-part start

$("#colorful").colorfulTab(); 

// plugin-part end




// last-part start

$('.lastslider').slick({
  autoplay:true,
  arrows:false,
  dots: false,
  infinite: true,
  speed: 300,
  slidesToShow: 5,
  slidesToScroll: 1,
});

// last-part end



//  scroll button

$(window).scroll(function(){
  if($(this).scrollTop() > 400){
    $('.topbtn').fadeIn();
  } else{
    $('.topbtn').fadeOut();
  }
})

$('.topbtn').click(function(){
  $('html,body').animate({scrollTop :0},800)
})

//  scroll button




// animation part








// animation part







